/*
package com.kgc.config;


import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import redis.clients.jedis.JedisPoolConfig;

*/
/*
* 完成对Redis的整合的一些配置
*
* *//*


@Configuration
public class RedisConfig {
    */
/*1.创建JesdispoolConfig对象，在该对象中完成一些链接池配置

    * *//*


    @Bean(name = "config")//Bean标记，其实就是当spring加载的时候会加载Configuration中的被标记bean元素的方法
    public JedisPoolConfig jedisPoolConfig(){
      JedisPoolConfig config =new JedisPoolConfig();
        //最大空闲数
        config.setMaxIdle(10);
        //最小
        config.setMinIdle(5);
        //最大链接数
        config.setMaxTotal(20);

        return config;

}

*/
/*
* 2 创建JedisConnectionFactory:配置reids信息
*配置redis连接对象，将工厂与配置文件连接起来
* *//*

    @Bean
    public JedisConnectionFactory jedisConnectionFactory( JedisPoolConfig config){
    JedisConnectionFactory factory =new JedisConnectionFactory();
        //关联连接池的配置对象
        factory.setPoolConfig(config);
        //配置连接Redis的信息
        //主机地址
        factory.setHostName("192.168.48.102");
//        factory.setUsePool(true);
        //端口
        factory.setPort(6379);

    return factory;
}

*/
/*
* 3 创建RedisTemlate ：用于执行Redis操作的方法
* *//*

    @Bean
    public RedisTemplate<String,Object> redisTemplate(@Qualifier("jedisConnectionFactory") JedisConnectionFactory factory){
        RedisTemplate<String,Object> template=new RedisTemplate<String, Object>();
        template.setConnectionFactory(factory);

//        template.setKeySerializer(new StringRedisSerializer());

        return template;

    }





}
*/
