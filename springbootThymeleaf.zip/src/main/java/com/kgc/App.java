package com.kgc;


import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/*Thymeleaf*/
@SpringBootApplication
@MapperScan("com.kgc.dao")//用于用户扫描mYbatis的mapper的接口
public class App {
    public static void main(String[] args) {
        SpringApplication.run(App.class,args);
    }


}
