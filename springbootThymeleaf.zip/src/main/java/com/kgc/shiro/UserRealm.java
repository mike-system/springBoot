package com.kgc.shiro;

import com.kgc.pojo.Users;
import com.kgc.service.UsersService;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.*;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.Resource;

public class UserRealm extends AuthorizingRealm {



    //授权
    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principalCollection) {
        System.out.println("执行授权");
        //给资源进行授权  只有授权过后才能使用
        SimpleAuthorizationInfo info =new SimpleAuthorizationInfo();
        //这里引用的是授权的字段必须一致
        //info.addStringPermission("user:add");

        //通过数据库查询当前登录用户的授权字符串
        //获取当前登录用户
        Subject subject = SecurityUtils.getSubject();
        Users user =(Users) subject.getPrincipal();

        Users dbUser=usersService.findById(user.getId());
        //授权信息
        info.addStringPermission(dbUser.getEmail());


        return info;
    }










    //调用UsersService层的方法，查询数据库中的数据
    @Resource
    private UsersService usersService;

    //认证
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken arg0) throws AuthenticationException {
        System.out.println("执行认证");
        //假设数据库用户名和密码
        /*String username ="eric";
        String password="123";*/

        //编写shir判断逻辑
        //首先获取页面的token
        UsernamePasswordToken token =(UsernamePasswordToken)arg0;
        //调用数据库
        Users user = usersService.findUsername(token.getUsername());
        //System.out.println(user);

        if(user==null){
            //用户名不存在
            return null; //shrio底层会抛出UnknowAccountException
        }
        //判断密码
        return  new SimpleAuthenticationInfo(user,user.getPassword(),"");



    }


}
