package com.kgc.shiro;


import at.pollux.thymeleaf.shiro.dialect.ShiroDialect;
import org.apache.shiro.spring.web.ShiroFilterFactoryBean;
import org.apache.shiro.web.mgt.DefaultWebSecurityManager;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.LinkedHashMap;
import java.util.Map;

/*
* Shiro的配置类
* */
@Configuration
public class ShiroConfig {


    /*
    * 1.创建ShiroFilterFactoryBean
    * */
    @Bean
    public ShiroFilterFactoryBean getShiroFilterFactoryBean(@Qualifier("securityManager") DefaultWebSecurityManager securityManager){
        ShiroFilterFactoryBean shiroFilterFactoryBean=new ShiroFilterFactoryBean();

        //设置安全管理器
        shiroFilterFactoryBean.setSecurityManager(securityManager);
        //添加shiro内置过滤器
        //放行anon
        /*Shiro内置过滤器，可以实现权限相关拦截器
        长用的的过滤器：anon无需验证（登录）可以访问
        authc:必须认证才可以访问
        *user :如果使用rememberMe的共能可以直接访问
        *perms：该资源必须资源权限才能访问
        role:该资源必须得到角色权限才能访问
        */

        Map<String,String> filterMap=new LinkedHashMap<String, String>();

        filterMap.put("/users/login","anon");
        //filterMap.put("/users/logout","anon");
        //拦截所有
        filterMap.put("/users/*","authc");

        //授权过滤器  当不想让普通用户访问这个页面，就直接提示您没有权限
        //当授权拦截后，shiro 会自动跳转到未授权的页面
        filterMap.put("/需要拦截的路径","perms[user:add]");



        //设置拦截后跳转的页面
        shiroFilterFactoryBean.setLoginUrl("/users/dologin");
        //未授权拦截后跳转到未授权的页面（如果想打开授权拦截就在Realm中配置授权打开）
       shiroFilterFactoryBean.setUnauthorizedUrl("/users/noAuth");

        shiroFilterFactoryBean.setFilterChainDefinitionMap(filterMap);






        return shiroFilterFactoryBean;
    }




    /*
    * 2.创建DfaultWebSecurityManager
    * 通过拿到Realm 所在的类进行产生关联
    * */
    @Bean(name = "securityManager")
    public DefaultWebSecurityManager getDefaultWebSecurityManager(@Qualifier("userRealm") UserRealm userRealm){
        DefaultWebSecurityManager securityManager =new DefaultWebSecurityManager();
       //关联 realm
        securityManager.setRealm(userRealm);
        return securityManager;
    }


    /*
    * 3.创建Realm
    * */
    @Bean(name = "userRealm") //方法放入spring环境中进行类与类之间的关联
        public UserRealm getRealm(){

            return  new UserRealm();
    }


    //配置ShiroDialect 用于thymeleaf和shiro标签配合使用
    @Bean
    public ShiroDialect getShiroDialect(){
        return new ShiroDialect();
    }



}
