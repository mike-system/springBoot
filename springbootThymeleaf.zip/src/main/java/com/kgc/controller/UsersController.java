package com.kgc.controller;

import com.kgc.pojo.Users;

import com.kgc.service.UsersService;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.IncorrectCredentialsException;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.springframework.stereotype.Controller;

import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

@Controller
@RequestMapping("/users")
public class UsersController {

    @Resource
    private UsersService usersService;
    /*页面跳转
     *通过el表达式
     */

    @RequestMapping("/{page}")
    public String showPage(@PathVariable String page) {

        return page;
    }

    @RequestMapping("/input")
    public String input(@ModelAttribute("aa")  Users users){
        return "input";
    }
    /*添加用户
    校验 ：1.对pojo层进行注解提示  2，当客户端请求服务器进入Controller 然后在传参定义@Valid
    通过BindingResult result 进行处理，然后如果有错返回请求页面，并给予提示信息
    else就直接执行增删改操作

     * */
    @RequestMapping("/addUser")
    public String addUser(@ModelAttribute("aa") @Valid Users users ,BindingResult result) {
            if(result.hasErrors()){
                return "input";
            }

            this.usersService.addUser(users);

        return "redirect:users/findAll";
    }

    /*查询用户信息
     * */
    @RequestMapping("/findAll")
    public String findall(Model model) {
        List<Users> list = this.usersService.findAll();
        System.out.println(list);
            model.addAttribute("list",list);
        return "UsersList";
    }

    //回显数据信息
    @RequestMapping("/findUserById")
    public  String findByid(Integer id,Model model){
        Users users =this.usersService.findById(id);
        model.addAttribute("users",users);


        return "updateUser";
    }


    //修改用户的信息
    @RequestMapping("/editUser")
    public String update(Users users){
    this.usersService.Modifier(users);

        return "redirect:/users/findAll";
    }

    @RequestMapping("/deleteId")
    public String delete(Integer id){
        int i = this.usersService.deleteUser(id);
        System.out.println(i);

        return "redirect:/users/findAll";
    }

    //登录编辑逻辑  (Shiro登录判断)
    @RequestMapping("/login")
    public String login(String username,String password,Model model){
        /*
        * 使用Shiro编写认证操作
        * */
        Subject subject = SecurityUtils.getSubject();
        //封装用户数据
        UsernamePasswordToken token =new UsernamePasswordToken(username,password);

        //执行登录方法
        try {
            subject.login(token);
            //登录成功
            return "redirect:/users/findAll";

            //登录失败：用户名不存在
        }catch (UnknownAccountException e){
            model.addAttribute("msg","用户名不存在");
        return  "login";
        }catch (IncorrectCredentialsException e){
        model.addAttribute("msg","密码错误");
            return  "login";
        }

    }

    /*拦截后登录跳转到的页面
    访问登录页面
    * */
    @RequestMapping("/dologin")
    public String dologin(){

        return "login";
    }

    /*
    * 授权页面拦截
    *
    * */
    @RequestMapping("/noAuth")
    public String nono(){

        return "noAuth";
    }





}
