package com.kgc.controller;


import com.kgc.pojo.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/*
* Thymeleaf案例
*
* */
@Controller

public class DemoController {
@RequestMapping("/show")
    public  String showInfo(Model model){

    model.addAttribute("msg","Thymeleaf第一个案例");
    model.addAttribute("key",new Date());
    return "index";



}
@RequestMapping("/show2")
    public  String info2(Model model){

    model.addAttribute("sex","女");
    model.addAttribute("id" ,"2");
    return "index2";


}
 @RequestMapping("/show3")
@ResponseBody
    public List<User> info3(){
    List<User> list =new ArrayList<User>();

    list.add(new User(1,"张三",23));
    list.add(new User(2,"张三",25));
    list.add(new User(3,"张三",24));


    return list;
 }

    @RequestMapping("/show5")
    public String showInfo5(HttpServletRequest request,Model model){
    request.setAttribute("req","HttpServletRequest");
    request.getSession().setAttribute("sess","HttpServletSession");
    request.getSession().getServletContext().setAttribute("app","Application");


    return  "index5";
    }

    //Thymeleaf的Url处理
    @RequestMapping("/show6")
    public  String show6(){



    return "index6";
    }







}
