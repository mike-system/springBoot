package com.kgc.service.imp;


import com.kgc.dao.UsersMapper;
import com.kgc.pojo.Users;
import com.kgc.service.UsersService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

@Service
@Transactional//为spring提供丰富的事务处理机制
public class UserServiceimpl implements UsersService {

    @Resource
    private UsersMapper UsersMapper;
    //增加用户信心
    @Override
    public void addUser(Users users) {
        this.UsersMapper.insertUser(users);
    }

    //回显数据查询
    @Override
    public Users findById(Integer id) {
        return this.UsersMapper.findById(id);
    }

    //修改用户信息
    @Override
    public void Modifier(Users users) {
        this.UsersMapper.Modifier(users);
    }

    //删除用户信息
    @Override
    public int deleteUser(Integer id) {
        return this.UsersMapper.deleteUser(id);
    }
    //根据用户名查询
    @Override
    public Users findUsername(String username) {
        return this.UsersMapper.findUsername(username);
    }


    //查询所有用户信息
    @Override
    public List<Users> findAll() {
      return   this.UsersMapper.findAll();

    }


}
