package com.kgc.service;

import com.kgc.pojo.Users;

import java.util.List;

public interface UsersService {
    //新增用户信息
    void  addUser(Users users);

    //查询用户信息
    List<Users> findAll();

    //回显数据
    Users findById(Integer id);

    //修改用户信息
     void Modifier(Users users);

     //删除用户信息
    int deleteUser(Integer id);

    Users findUsername(String username);

}
