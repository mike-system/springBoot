package com.kgc.dao;

import com.kgc.pojo.User;
import com.kgc.pojo.Users;

import java.util.List;

public interface UsersMapper {
    //增加用户信息

    void insertUser (Users users);

    //查询用户信息
    List<Users> findAll();
    //根据id查询  回显数据
    Users findById(Integer id);
    //修改用户
    void Modifier(Users users);

    //删除用户
    int deleteUser(Integer id);

    //根据用户名进行查询
    Users findUsername(String username);


}
