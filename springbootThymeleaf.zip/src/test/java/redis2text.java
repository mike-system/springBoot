/*
import com.kgc.App;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = App.class)
public class redis2text {

    @Resource
    private RedisTemplate<String,Object> redisTemplate;


    @Test
    public void textSet(){
        this.redisTemplate.opsForValue().set("key","风急天高猿啸鸣");
    }




}
*/
