import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kgc.App;
import com.kgc.pojo.Users;
import com.kgc.service.UsersService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;
import java.util.List;

//代表测是执行  测试redis
@RunWith(SpringRunner.class)
@SpringBootTest(classes = App.class)
public class text {

    //通过模板
    @Autowired
    private RedisTemplate<String, String> redisTemplate;

    @Resource
    private UsersService usersService;

    @Test
    public void test() throws JsonProcessingException {
        //从redis中获得数据，数据的形式json字符串
        String userListJson = redisTemplate.boundValueOps("Users.findAll").get();

        //判断redis中是否存在数据  如果不存在数据就直接将数据库中查询的数据写入redis缓存中
        if (null == userListJson) {
            //不存在数据 从数据库查询
            List<Users> all = usersService.findAll();
            //将查询出的数据存储到redis缓存中
            //先将list集合转换位json格式的字符串，使用jackson
            ObjectMapper objectMapper = new ObjectMapper();
            //将数据库中的数据写入userListJson
            userListJson = objectMapper.writeValueAsString(all);

            redisTemplate.boundValueOps("Users.findAll").set(userListJson);

            System.out.println("========从数据库中获得user的数据 "+userListJson);
        } else {
            System.out.println("======从redis中缓存中或的数据"+userListJson);

        }


        //将数据在控制台打印
        System.out.println(userListJson);

    }


}
